package com.myhope.practice

object MyHopeServiceApplication extends App {
  MyHopeService.start()
}
