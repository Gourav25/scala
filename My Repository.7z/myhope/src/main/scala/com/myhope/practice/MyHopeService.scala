package com.myhope.practice

import akka.actor.ActorSystem
import com.myhope.config.Config
import com.myhope.jms.{MessageListener, MyQueueListener}
import com.typesafe.config.ConfigFactory

object MyHopeService {

  val system: ActorSystem =
    ActorSystem(Config.actorConfig.system, ConfigFactory.load("my-akka.conf"))

  lazy val messageListeners: Seq[MessageListener] = Seq(MyQueueListener)

  def start(): Unit =
    messageListeners.foreach(listener => listener.start())

}