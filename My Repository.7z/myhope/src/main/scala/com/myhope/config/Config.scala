package com.myhope.config

import java.io.{File, FileInputStream, InputStream}
import java.security.KeyStore

import javax.jms.ConnectionFactory
import javax.naming.Context
import javax.net.ssl.{SSLContext, TrustManager, TrustManagerFactory}
import com.marklogic.client.{DatabaseClient, DatabaseClientFactory}
import com.marklogic.client.DatabaseClientFactory.Authentication
import com.solacesystems.jms.{SolJmsUtility, SupportedProperty}
import com.typesafe.config.ConfigFactory
import org.springframework.jms.connection.CachingConnectionFactory
import pureconfig.loadConfigOrThrow


object Config {

  private val txnProcessorConf = ConfigFactory.load("my-hope.conf")

  val solaceConfig: SolaceConfig =
    loadConfigOrThrow[SolaceConfig](txnProcessorConf, "my-hope.solace")

  val actorConfig: ActorConfig =
    loadConfigOrThrow[ActorConfig](txnProcessorConf, "my-hope.akka.actor")

  val httpConfig: HttpConfig =
    loadConfigOrThrow[HttpConfig](txnProcessorConf, "my-hope.http")

}

final case class HttpConfig(httpHost: String, httpSwaggerPort: Int)

final case class SolaceConfig(url: String,
                              username: String,
                              password: String,
                              vpn: String,
                              jndi: String,
                              connFactory: String,
                              trustStore: String,
                              trustStoreFormat: String,
                              trustStorePassword: String,
                              extendedProps: String,
                              myQueue: String,
                              jmsConsumerBufferSize: Int) {

  private def solaceContext(): java.util.Hashtable[String, AnyRef] = {
    val env = new java.util.Hashtable[String, AnyRef]
    env.put(Context.INITIAL_CONTEXT_FACTORY, "com.solacesystems.jndi.SolJNDIInitialContextFactory")
    env.put(Context.PROVIDER_URL, url)
    env.put(Context.SECURITY_PRINCIPAL, s"$username@$vpn")
    env.put(Context.SECURITY_CREDENTIALS, password)
    //   env.put(Context.SECURITY_CREDENTIALS, ItracEncryptor.decrypt(password))
    env.put(SupportedProperty.SOLACE_JMS_VPN, vpn)
    env.put(SupportedProperty.SOLACE_JMS_SSL_TRUST_STORE, trustStore)
    env.put(SupportedProperty.SOLACE_JMS_SSL_TRUST_STORE_FORMAT, trustStoreFormat)
    env.put("ExtendedProps", extendedProps)

    env
  }

  def connectionFactory(): ConnectionFactory =
    SolJmsUtility.createConnectionFactory(solaceContext())

  def cachedConnectionFactory(): ConnectionFactory =
    new CachingConnectionFactory(SolJmsUtility.createConnectionFactory(solaceContext()))

}

final case class ActorConfig(system: String, filterThreads: Int, processorThreads: Int)

