package com.myhope.pipeline

import akka.NotUsed
import akka.stream._
import akka.stream.scaladsl.GraphDSL.Implicits._
import akka.stream.scaladsl.{Broadcast, Flow, GraphDSL, Partition, Sink}
import org.slf4j.{Logger, LoggerFactory}

import com.myhope.actor.ActorStreamConfig
import com.myhope.domain.{Meta, PreProcessorMessage}
import org.slf4j.{Logger, LoggerFactory}

object PipelineExecutor {
  def apply(): PipelineExecutor = new PipelineExecutor()
}

class PipelineExecutor extends ActorStreamConfig {
  val log: Logger = LoggerFactory.getLogger(classOf[PipelineExecutor])

  val decider: Supervision.Decider = {
    case ex: Exception =>
      log.error("Unexpected exception. ", ex)
      Supervision.Resume
  }

  val updateInputMessageToPersistMessageFlow: Flow[PreProcessorMessage, Unit, NotUsed] =
    Flow[PreProcessorMessage].map { x =>
      print(x);      print(x+"ssssss");

    }


  val pipelineFlow: Graph[FlowShape[PreProcessorMessage, Unit], NotUsed] =
    GraphDSL
      .create() { implicit builder =>
        val updateInputMessageToPersistMessageStage =
          builder.add(updateInputMessageToPersistMessageFlow)

        // @formatter:off
        // scalastyle:off
      //  updateInputMessageToPersistMessageStage.in
        updateInputMessageToPersistMessageStage
        // scalastyle:on
        // @formatter:on

        FlowShape(updateInputMessageToPersistMessageStage.in,updateInputMessageToPersistMessageStage.out)
      }
      .withAttributes(ActorAttributes.supervisionStrategy(decider))
      .named("pipelineGraph")

  val pipeline: Sink[PreProcessorMessage, NotUsed] =
    Flow[PreProcessorMessage].via(pipelineFlow).to(Sink.ignore)

}

