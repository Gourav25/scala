package com.myhope.domain

class MessageWrapper {

}

case class PreProcessorMessage(inputXml: String, splunkMeta: Meta)  {
  def raw: String = inputXml
}