package com.myhope.domain

import org.slf4j.LoggerFactory

import scala.util.{Failure, Success, Try}
import scala.xml.{Elem, XML}

case class Meta(messageId: String, source: String)

object Meta {
  private val log = LoggerFactory.getLogger(classOf[Meta])

  val empty: Meta = Meta(messageId="", source = "")

  def isEmpty(meta: Meta): Boolean =
    meta == empty

  def apply(xml: String): Meta =
    Try {
      toMeta(xml)
    } match {
      case Success(meta) =>
        meta
      case Failure(e) =>
        log.error(s"Unable to extract meta information from xml: $xml", e)
        Meta.empty
    }

  private def toMeta(xml: String): Meta = {
    val rootElem   = XML.loadString(xml)

    Meta.empty.copy(source = rootElem.toString(), messageId = messageId(rootElem))
  }

  private def messageId(rootElem: Elem): String =
    (rootElem \\ "ng" ).text.trim
}


