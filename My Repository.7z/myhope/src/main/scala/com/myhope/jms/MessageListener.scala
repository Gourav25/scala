package com.myhope.jms

import java.time.{LocalDateTime, LocalTime, ZonedDateTime}

import scala.util.{Failure, Success, Try}
import akka.NotUsed
import akka.stream.{ActorAttributes, KillSwitch, Supervision}
import akka.stream.scaladsl.{Sink, Source}
import com.myhope.actor.ActorStreamConfig
import com.myhope.domain.{Meta, PreProcessorMessage}
import com.myhope.pipeline.PipelineExecutor
import org.slf4j.{Logger, LoggerFactory}

trait MessageListener extends ActorStreamConfig  {

  val log: Logger = LoggerFactory.getLogger(classOf[MessageListener])

  val decider: Supervision.Decider = {
    case ex: Exception =>
      log.error("Unexpected exception. ", ex)
      Supervision.Resume
  }

  lazy val jmsPipeline: KillSwitch =
    jmsSource.map { msg =>
      log.info(s"From $queue, received message: $msg")
      val meta                = Meta(msg)
      val preProcessorMessage = PreProcessorMessage(msg, meta)
      preProcessorMessage
    }.to(pipeline)
      .withAttributes(ActorAttributes.supervisionStrategy(decider))
      .run()


  def start(): Unit = {
    log.info("Invoking listener: {}", queue)
    jmsPipeline
    log.info("listener:{} started", queue)
  }

  def stop(): Unit = {
    log.info(s"Stopping ${this.queue}")
    Try(jmsPipeline.shutdown()) match {
      case Success(result) =>
        log.info(s"jms pipeline of ${this.queue} stopped, $result")
      case Failure(ex) =>
        log.error(s"Listener detaching error ${ex.getMessage}", ex)
    }
  }

  def jmsSource: Source[String, KillSwitch] =
    JmsProvider.instance.jmsSource(queue)

  def queue: String

  def pipeline: Sink[PreProcessorMessage, NotUsed] =
    PipelineExecutor().pipeline

}

object MyQueueListener extends MessageListener {
  override def queue: String = JmsProvider.myQueue

}
