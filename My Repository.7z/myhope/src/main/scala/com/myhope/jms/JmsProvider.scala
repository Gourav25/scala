package com.myhope.jms

import javax.jms.ConnectionFactory

import scala.concurrent.Future

import akka.Done
import akka.stream.KillSwitch
import akka.stream.alpakka.jms._
import akka.stream.alpakka.jms.scaladsl.{JmsConsumer, JmsProducer}
import akka.stream.scaladsl.{Sink, Source}
import com.myhope.config.Config.solaceConfig

object JmsProvider {

  val instance = new JmsProvider(solaceConfig.connectionFactory(), solaceConfig
    .cachedConnectionFactory())
  val myQueue: String = solaceConfig.myQueue
  val bufferSize: Int = solaceConfig.jmsConsumerBufferSize
}

class JmsProvider(connFactory: ConnectionFactory, cachedConnFactory: ConnectionFactory) {

  def jmsSource(queue: String): Source[String, KillSwitch] =
    JmsConsumer.textSource(
      JmsConsumerSettings(connFactory)
        .withBufferSize(JmsProvider.bufferSize)
        .withQueue(queue)
    )

  def jmsSink(topic: String): Sink[String, Future[Done]] =
    JmsProducer.textSink(JmsProducerSettings(cachedConnFactory).withTopic(topic))
}