package com.myhope.actor

import akka.actor.ActorSystem
import akka.stream.{ActorMaterializer, ActorMaterializerSettings, Supervision}
import com.myhope.practice.MyHopeService
import org.slf4j.{Logger, LoggerFactory}

trait ActorStreamConfig {

  val logger: Logger = LoggerFactory.getLogger(classOf[ActorStreamConfig])
  private val decider: Supervision.Decider = {
    case ex: Exception =>
      logger.error("Unexpected exception. ", ex)
      Supervision.Resume // Required to stop the stream in case of failure
  }

  implicit val actorSystem: ActorSystem = MyHopeService.system
  implicit val materializer: ActorMaterializer = ActorMaterializer(
    ActorMaterializerSettings(actorSystem)
      .withSupervisionStrategy(decider)
  )

}
