myhope- This is very basic Project. With Solace Connection, And Akka Steam, Flows. One Message has been tested
	Message tested is "<nh>hiiiiertegergedfg</nh>" <- Text Inside Double Quote is used for testing.
	Gradle, Scala, Nexus, Solace Integration Exists in this project

